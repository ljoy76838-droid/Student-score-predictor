from pathlib import Path
import json, sqlite3, csv, io
import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, g
from flask_cors import CORS

ROOT=Path(__file__).resolve().parent
DB=ROOT/'students.db'; MODEL_PATH=ROOT/'model.joblib'; META_PATH=ROOT/'model_meta.json'
FEATURES=['attendance','study_hours','previous_score','assignments','internal_marks','participation','sleep_hours']
app=Flask(__name__); CORS(app)

def get_db():
    if 'db' not in g:
        g.db=sqlite3.connect(DB); g.db.row_factory=sqlite3.Row
    return g.db
@app.teardown_appcontext
def close_db(_):
    db=g.pop('db',None)
    if db: db.close()

def init_db():
    db=sqlite3.connect(DB)
    db.execute('''CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, student_code TEXT UNIQUE NOT NULL, course TEXT DEFAULT 'B.Tech CSE', semester TEXT DEFAULT '6th', attendance REAL, study_hours REAL, previous_score REAL, assignments REAL, internal_marks REAL, participation REAL, sleep_hours REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    count=db.execute('SELECT COUNT(*) FROM students').fetchone()[0]
    if count==0:
        samples=[('Aarav Sharma','STU-DEMO-01'),('Ishita Verma','STU-DEMO-02'),('Rohan Singh','STU-DEMO-03'),('Priya Gupta','STU-DEMO-04'),('Kabir Khan','STU-DEMO-05'),('Ananya Mishra','STU-DEMO-06'),('Aditya Patel','STU-DEMO-07'),('Meera Joshi','STU-DEMO-08')]
        vals=[(n,c,'B.Tech CSE',str(4+i%3)+'th',v[0],v[1],v[2],v[3],v[4],v[5],v[6]) for i,(n,c) in enumerate(samples) for v in [((82+i*2)%101,2.5+i*.45,60+i*3,70+i*2,65+i*2,55+i*4,6.2+i*.2)]]
        db.executemany('INSERT INTO students(name,student_code,course,semester,attendance,study_hours,previous_score,assignments,internal_marks,participation,sleep_hours) VALUES(?,?,?,?,?,?,?,?,?,?,?)',vals); db.commit()
    db.close()

def model():
    if not MODEL_PATH.exists():
        import train_model; train_model.train()
    return joblib.load(MODEL_PATH)

def payload():
    data=request.get_json(silent=True) or {}
    missing=[f for f in FEATURES if f not in data]
    if missing: raise ValueError('Missing fields: '+', '.join(missing))
    vals={f:float(data[f]) for f in FEATURES}
    ranges={'attendance':(0,100),'study_hours':(0,24),'previous_score':(0,100),'assignments':(0,100),'internal_marks':(0,100),'participation':(0,100),'sleep_hours':(0,24)}
    for f,(lo,hi) in ranges.items():
        if not lo<=vals[f]<=hi: raise ValueError(f'{f} must be between {lo} and {hi}')
    return vals

def band(score):
    if score>=85: return {'label':'Excellent','tone':'emerald','advice':'Maintain the current routine and protect consistency.'}
    if score>=70: return {'label':'Strong','tone':'blue','advice':'A little more consistency can move the forecast upward.'}
    if score>=50: return {'label':'Developing','tone':'amber','advice':'Prioritize attendance, focused study blocks and assignment completion.'}
    return {'label':'At Risk','tone':'rose','advice':'Build a weekly recovery plan and seek academic support early.'}

def predict_one(vals):
    m=model(); score=float(np.clip(m.predict(pd.DataFrame([vals],columns=FEATURES))[0],0,100)); b=band(score)
    # Transparent heuristic guidance, not a confidence probability.
    impacts=m.feature_importances_; ranked=sorted(zip(FEATURES,impacts),key=lambda x:x[1],reverse=True)
    return {'predicted_score':round(score,1),'band':b,'top_drivers':[{'feature':f,'importance':round(float(i),3)} for f,i in ranked[:5]],'disclaimer':'Demonstration prediction from a model trained on synthetic data.'}

@app.errorhandler(Exception)
def errors(e): return jsonify({'error':str(e)}),400
@app.get('/api/health')
def health(): return jsonify({'status':'ok','service':'StudentIQ API'})
@app.get('/api/dashboard')
def dashboard():
    db=get_db(); rows=db.execute('SELECT * FROM students ORDER BY id DESC').fetchall(); records=[dict(r) for r in rows]
    scores=[predict_one({f:r[f] for f in FEATURES})['predicted_score'] for r in records] if records else []
    avg=float(np.mean(scores)) if scores else 0
    return jsonify({'students':len(records),'average_predicted_score':round(avg,1),'at_risk':sum(s<50 for s in scores),'strong':sum(s>=70 for s in scores),'score_distribution':[{'range':'0-49','count':sum(s<50 for s in scores)},{'range':'50-69','count':sum(50<=s<70 for s in scores)},{'range':'70-84','count':sum(70<=s<85 for s in scores)},{'range':'85-100','count':sum(s>=85 for s in scores)}],'trend':[{'label':f'W{i+1}','score':round(max(45,avg+(i-3)*1.8),1)} for i in range(6)]})
@app.get('/api/students')
def students():
    db=get_db(); rows=db.execute('SELECT * FROM students ORDER BY id DESC').fetchall(); out=[]
    for r in rows:
        d=dict(r); p=predict_one({f:d[f] for f in FEATURES}); d.update(predict=p['predicted_score'],band=p['band']['label']); out.append(d)
    return jsonify(out)
@app.post('/api/students')
def add_student():
    data=request.get_json() or {}; required=['name','student_code']+FEATURES
    for k in required:
        if k not in data: raise ValueError('Missing field: '+k)
    vals=payload_from(data); db=get_db(); cur=db.execute('INSERT INTO students(name,student_code,course,semester,attendance,study_hours,previous_score,assignments,internal_marks,participation,sleep_hours) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(data['name'],data['student_code'],data.get('course','B.Tech CSE'),data.get('semester','6th'),*[vals[f] for f in FEATURES])); db.commit(); return jsonify({'id':cur.lastrowid}),201
@app.delete('/api/students/<int:sid>')
def delete_student(sid):
    db=get_db(); cur=db.execute('DELETE FROM students WHERE id=?',(sid,)); db.commit(); return jsonify({'deleted':cur.rowcount==1})
def payload_from(data):
    missing=[f for f in FEATURES if f not in data]
    if missing: raise ValueError('Missing fields: '+', '.join(missing))
    vals={f:float(data[f]) for f in FEATURES};
    for f in FEATURES:
        if vals[f]<0 or (f!='study_hours' and f!='sleep_hours' and vals[f]>100): raise ValueError('Invalid value for '+f)
    return vals
@app.post('/api/predict')
def predict(): return jsonify(predict_one(payload()))
@app.post('/api/predict/batch')
def batch():
    file=request.files.get('file')
    if not file: raise ValueError('Attach a CSV file under form field "file"')
    df=pd.read_csv(file); missing=[f for f in FEATURES if f not in df.columns]
    if missing: raise ValueError('CSV missing columns: '+', '.join(missing))
    results=[]
    for _,r in df.iterrows(): results.append(predict_one({f:float(r[f]) for f in FEATURES})['predicted_score'])
    df['predicted_score']=results; out=io.StringIO(); df.to_csv(out,index=False); return jsonify({'rows':len(df),'csv':out.getvalue()})
@app.get('/api/model/insights')
def insights():
    meta=json.loads(META_PATH.read_text()) if META_PATH.exists() else {}; m=model(); imp=sorted(zip(FEATURES,m.feature_importances_),key=lambda x:x[1],reverse=True)
    return jsonify({**meta,'feature_importance':[{'feature':f,'importance':round(float(v),4)} for f,v in imp]})

if __name__=='__main__':
    init_db();
    if not MODEL_PATH.exists():
        import train_model; train_model.train()
    app.run(host='0.0.0.0',port=5000,debug=True)

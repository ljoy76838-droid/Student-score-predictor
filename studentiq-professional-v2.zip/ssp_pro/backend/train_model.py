from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

ROOT = Path(__file__).resolve().parent
DATA = ROOT.parent / 'data' / 'student_performance.csv'
MODEL = ROOT / 'model.joblib'
META = ROOT / 'model_meta.json'
FEATURES = ['attendance','study_hours','previous_score','assignments','internal_marks','participation','sleep_hours']

def create_dataset(n=2400, seed=42):
    rng=np.random.default_rng(seed)
    attendance=rng.uniform(45,100,n)
    study=rng.uniform(.5,8,n)
    previous=rng.uniform(30,95,n)
    assignments=rng.uniform(35,100,n)
    internal=rng.uniform(30,95,n)
    participation=rng.uniform(20,100,n)
    sleep=rng.uniform(4.5,9,n)
    noise=rng.normal(0,4.5,n)
    score=(0.18*attendance+2.8*study+0.30*previous+0.12*assignments+0.18*internal+0.07*participation+1.0*sleep+noise)
    score=np.clip(score,0,100)
    df=pd.DataFrame({
        'student_id':[f'STU-{i:04d}' for i in range(1,n+1)],
        'attendance':np.round(attendance,1),'study_hours':np.round(study,1),'previous_score':np.round(previous,1),
        'assignments':np.round(assignments,1),'internal_marks':np.round(internal,1),'participation':np.round(participation,1),
        'sleep_hours':np.round(sleep,1),'final_score':np.round(score,1)
    })
    DATA.parent.mkdir(parents=True,exist_ok=True); df.to_csv(DATA,index=False); return df

def train():
    df=create_dataset()
    X=df[FEATURES]; y=df.final_score
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42)
    model=RandomForestRegressor(n_estimators=300,max_depth=14,min_samples_leaf=3,random_state=42,n_jobs=-1)
    model.fit(Xtr,ytr)
    pred=model.predict(Xte)
    meta={'features':FEATURES,'mae':round(float(mean_absolute_error(yte,pred)),2),'r2':round(float(r2_score(yte,pred)),3),'training_rows':len(df),'model':'RandomForestRegressor','note':'Synthetic demonstration data; retrain with real validated data before real-world use.'}
    joblib.dump(model,MODEL); META.write_text(json.dumps(meta,indent=2)); print(json.dumps(meta,indent=2))

if __name__=='__main__': train()

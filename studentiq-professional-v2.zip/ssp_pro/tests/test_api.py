import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'backend'))
from app import app, init_db

def test_health():
    app.config['TESTING']=True
    with app.test_client() as c:
        assert c.get('/api/health').status_code==200

def test_predict():
    app.config['TESTING']=True
    with app.test_client() as c:
        payload={'attendance':90,'study_hours':4,'previous_score':80,'assignments':90,'internal_marks':82,'participation':75,'sleep_hours':7}
        r=c.post('/api/predict',json=payload); assert r.status_code==200; assert 0<=r.json['predicted_score']<=100
